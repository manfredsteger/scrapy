
import React, { useState, useCallback, useRef, useEffect, useMemo } from 'react';
import { Plus, LayoutGrid, ChevronRight, RefreshCw, Trash2, ArrowLeft, Play, Square, Globe, Loader2, FileJson, FileSpreadsheet, Search, AlertCircle, PlusCircle, Upload, CheckCircle2, Download, Database, Pencil, Check, X, Settings, Sliders, ShieldCheck, History, ScanText, FileText, Layers } from 'lucide-react';
import { SitemapService } from './services/sitemapService';
import { StorageService } from './services/storageService';
import { ScraperProject, SitemapUrlEntry, ScrapingError } from './types';
import Header from './components/Header';
import StatsCards from './components/StatsCards';
import UrlList from './components/UrlList';
import ErrorLogs from './components/ErrorLogs';

const BATCH_SIZE = 5; // Parallel workers for extraction

const App: React.FC = () => {
  const [projects, setProjects] = useState<ScraperProject[]>([]);
  const [activeProjectId, setActiveProjectId] = useState<string | null>(null);
  const [domainInput, setDomainInput] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [activeTab, setActiveTab] = useState<'urls' | 'errors'>('urls');
  const [isLoadingDB, setIsLoadingDB] = useState(true);
  const [showSettings, setShowSettings] = useState(false);
  
  const [editingProjectId, setEditingProjectId] = useState<string | null>(null);
  const [editTitleValue, setEditTitleValue] = useState('');
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const settingsRef = useRef<HTMLDivElement>(null);

  const activeProject = useMemo(() => 
    projects.find(p => p.id === activeProjectId), 
  [projects, activeProjectId]);

  useEffect(() => {
    StorageService.getAllProjects().then(p => {
      setProjects(p.sort((a, b) => new Date(b.lastScraped).getTime() - new Date(a.lastScraped).getTime()));
      setIsLoadingDB(false);
    });
  }, []);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (settingsRef.current && !settingsRef.current.contains(event.target as Node)) {
        setShowSettings(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const syncProjectToDB = useCallback(async (project: ScraperProject) => {
    await StorageService.saveProject(project);
  }, []);

  const createProject = async (domain: string) => {
    if (!domain) return;
    setIsProcessing(true);
    const id = Date.now().toString();
    try {
      const discovered = await SitemapService.discoverSitemaps(domain);
      const newProject: ScraperProject = {
        id,
        domain: domain.replace(/^https?:\/\//, '').replace(/\/$/, ''),
        lastScraped: new Date().toISOString(),
        status: 'scraping',
        queue: discovered,
        processed: [],
        results: [],
        errors: [],
        stats: {
          totalSitemaps: discovered.length,
          processedSitemaps: 0,
          totalUrls: 0,
          totalImages: 0,
          totalVideos: 0,
          startTime: Date.now(),
          scrapedPages: 0
        }
      };
      await syncProjectToDB(newProject);
      setProjects(prev => [newProject, ...prev]);
      setActiveProjectId(id);
      setDomainInput('');
    } catch (err) {
      alert("Initialization error.");
    } finally {
      setIsProcessing(false);
    }
  };

  const startContentScrape = () => {
    if (!activeProject) return;
    const contentLikelyUrls = activeProject.results
      .filter(r => !r.scrapedData && SitemapService.isLikelyContentPage(r.loc))
      .map(r => r.loc);

    if (contentLikelyUrls.length === 0) {
      alert("No content pages (.php, .html) detected for deep scraping.");
      return;
    }

    setProjects(prev => prev.map(p => p.id === activeProjectId ? { 
      ...p, 
      status: 'content_scraping',
      queue: contentLikelyUrls
    } : p));
    setShowSettings(false);
  };

  const deleteProject = async (id: string, e?: React.MouseEvent) => {
    e?.stopPropagation();
    if (confirm("Permanently delete this crawl data?")) {
      await StorageService.deleteProject(id);
      setProjects(prev => prev.filter(p => p.id !== id));
      if (activeProjectId === id) setActiveProjectId(null);
    }
  };

  const exportProject = useCallback((project: ScraperProject) => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(project, null, 2));
    const downloadAnchorNode = document.createElement('a');
    downloadAnchorNode.setAttribute("href", dataStr);
    downloadAnchorNode.setAttribute("download", `${project.domain.replace(/[^a-z0-9]/gi, '_')}-export.json`);
    document.body.appendChild(downloadAnchorNode);
    downloadAnchorNode.click();
    downloadAnchorNode.remove();
  }, []);

  const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async (event) => {
      const content = event.target?.result as string;
      try {
        if (file.name.endsWith('.json')) {
          const importedProject = JSON.parse(content) as ScraperProject;
          importedProject.id = Date.now().toString();
          importedProject.lastScraped = new Date().toISOString();
          await syncProjectToDB(importedProject);
          setProjects(prev => [importedProject, ...prev]);
          setActiveProjectId(importedProject.id);
        } else {
          const { urls, subSitemaps } = SitemapService.parseSitemap(content);
          const id = Date.now().toString();
          const newProject: ScraperProject = {
            id,
            domain: file.name,
            lastScraped: new Date().toISOString(),
            status: 'idle',
            queue: subSitemaps,
            processed: [],
            results: urls,
            errors: [],
            stats: {
              totalSitemaps: subSitemaps.length,
              processedSitemaps: 0,
              totalUrls: urls.length,
              totalImages: urls.reduce((a, c) => a + (c.images?.length || 0), 0),
              totalVideos: 0,
              startTime: Date.now(),
              scrapedPages: 0
            }
          };
          await syncProjectToDB(newProject);
          setProjects(prev => [newProject, ...prev]);
          setActiveProjectId(id);
        }
      } catch (err) {
        alert("Import failed. Check file format.");
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const handleRename = async (id: string, newName: string) => {
    const updatedProjects = projects.map(p => {
      if (p.id === id) {
        const updated = { ...p, domain: newName };
        syncProjectToDB(updated);
        return updated;
      }
      return p;
    });
    setProjects(updatedProjects);
    setEditingProjectId(null);
  };

  const processStep = useCallback(async () => {
    const scrapingProject = projects.find(p => p.status === 'scraping');
    if (scrapingProject) {
      if (scrapingProject.queue.length === 0) {
        const updated = { ...scrapingProject, status: 'idle' as const };
        await syncProjectToDB(updated);
        setProjects(prev => prev.map(p => p.id === scrapingProject.id ? updated : p));
        return;
      }

      const batchUrls = scrapingProject.queue.slice(0, BATCH_SIZE);
      const remainingQueueAfterBatch = scrapingProject.queue.slice(BATCH_SIZE);
      
      const batchResults = await Promise.all(batchUrls.map(async (url) => {
        try {
          const xml = await SitemapService.fetchWithProxy(url);
          return { url, data: SitemapService.parseSitemap(xml, scrapingProject.domain), error: null };
        } catch (err) {
          return { url, data: null, error: (err as Error).message };
        }
      }));

      setProjects(prev => {
        return prev.map(p => {
          if (p.id !== scrapingProject.id) return p;
          let newResults = [...p.results];
          let newQueue = [...remainingQueueAfterBatch];
          let newProcessed = [...p.processed, ...batchUrls];
          let newErrors = [...p.errors];
          let sitemapsProcessedInBatch = 0;
          let newSitemapsFound = 0;

          batchResults.forEach(res => {
            sitemapsProcessedInBatch++;
            if (res.data) {
              const { urls, subSitemaps } = res.data;
              const existingLocs = new Set(newResults.map(r => r.loc));
              const uniqueNewUrls = urls.filter(u => !existingLocs.has(u.loc));
              newResults = [...newResults, ...uniqueNewUrls];
              const filteredSub = subSitemaps.filter(s => !newProcessed.includes(s) && !newQueue.includes(s));
              newQueue = [...newQueue, ...filteredSub];
              newSitemapsFound += filteredSub.length;
            } else if (res.error) {
              newErrors.push({ url: res.url, message: res.error, timestamp: new Date().toISOString() });
            }
          });

          const updated = {
            ...p,
            queue: newQueue,
            processed: newProcessed,
            results: newResults,
            errors: newErrors,
            lastScraped: new Date().toISOString(),
            stats: {
              ...p.stats,
              processedSitemaps: p.stats.processedSitemaps + sitemapsProcessedInBatch,
              totalSitemaps: p.stats.totalSitemaps + newSitemapsFound,
              totalUrls: newResults.length,
              totalImages: newResults.reduce((acc, curr) => acc + (curr.images?.length || 0), 0),
            }
          };
          syncProjectToDB(updated);
          return updated;
        });
      });
      return;
    }

    const contentScrapingProject = projects.find(p => p.status === 'content_scraping');
    if (contentScrapingProject) {
      if (contentScrapingProject.queue.length === 0) {
        const updated = { ...contentScrapingProject, status: 'idle' as const };
        await syncProjectToDB(updated);
        setProjects(prev => prev.map(p => p.id === contentScrapingProject.id ? updated : p));
        return;
      }

      const batchUrls = contentScrapingProject.queue.slice(0, BATCH_SIZE);
      const remainingQueueAfterBatch = contentScrapingProject.queue.slice(BATCH_SIZE);

      const batchResults = await Promise.all(batchUrls.map(async (url) => {
        try {
          const data = await SitemapService.scrapePageContent(url);
          return { url, data, error: null };
        } catch (err) {
          return { url, data: null, error: (err as Error).message };
        }
      }));

      setProjects(prev => {
        return prev.map(p => {
          if (p.id !== contentScrapingProject.id) return p;
          let newResults = [...p.results];
          let newErrors = [...p.errors];
          let scrapedInBatch = 0;

          batchResults.forEach(res => {
            if (res.data) {
              newResults = newResults.map(r => r.loc === res.url ? { ...r, scrapedData: res.data! } : r);
              scrapedInBatch++;
            } else if (res.error) {
              newErrors.push({ url: res.url, message: "Extract Error: " + res.error, timestamp: new Date().toISOString() });
            }
          });

          const updated = {
            ...p,
            queue: remainingQueueAfterBatch,
            results: newResults,
            errors: newErrors,
            stats: { ...p.stats, scrapedPages: (p.stats.scrapedPages || 0) + scrapedInBatch }
          };
          syncProjectToDB(updated);
          return updated;
        });
      });
    }
  }, [projects, syncProjectToDB]);

  useEffect(() => {
    const active = projects.find(p => p.status === 'scraping' || p.status === 'content_scraping');
    if (active) {
      const timer = setTimeout(processStep, active.status === 'scraping' ? 200 : 800);
      return () => clearTimeout(timer);
    }
  }, [projects, processStep]);

  const progressPercent = useMemo(() => {
    if (!activeProject) return 0;
    if (activeProject.status === 'scraping') {
      const total = activeProject.processed.length + activeProject.queue.length;
      return total === 0 ? 0 : Math.min(100, Math.round((activeProject.processed.length / total) * 100));
    }
    if (activeProject.status === 'content_scraping') {
      const scraped = activeProject.results.filter(r => r.scrapedData).length;
      const total = activeProject.results.length;
      return total === 0 ? 0 : Math.min(100, Math.round((scraped / total) * 100));
    }
    return 0;
  }, [activeProject]);

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900">
      <Header onLogoClick={() => setActiveProjectId(null)} />
      
      <main className="flex-1 max-w-7xl mx-auto w-full px-4 py-8">
        {isLoadingDB ? (
          <div className="flex flex-col items-center justify-center py-40 text-slate-400">
            <Loader2 className="h-12 w-12 animate-spin mb-4" />
            <p className="font-bold tracking-tight uppercase tracking-widest text-[11px]">Database Sync...</p>
          </div>
        ) : !activeProjectId ? (
          <div className="space-y-12">
            <div className="bg-white rounded-3xl shadow-xl shadow-indigo-100 border border-slate-200 p-10 text-center max-w-3xl mx-auto">
              <div className="inline-flex p-4 rounded-3xl bg-indigo-600 text-white mb-8">
                <Database className="h-10 w-10" />
              </div>
              <h2 className="text-3xl font-black text-slate-900 mb-3 tracking-tight">Enterprise Content Crawler</h2>
              <p className="text-slate-500 mb-10 text-lg">Deeply analyze websites. Discover sitemaps and extract sequential DOM data.</p>
              
              <div className="flex flex-col md:flex-row gap-3 items-center">
                <div className="relative flex-1 w-full">
                  <div className="absolute inset-y-0 left-0 pl-5 flex items-center pointer-events-none">
                    <Search className="h-6 w-6 text-slate-400" />
                  </div>
                  <input
                    type="text"
                    className="block w-full pl-14 pr-6 py-5 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 transition-all text-lg font-medium"
                    placeholder="Enter domain (e.g. example.com)"
                    value={domainInput}
                    onChange={(e) => setDomainInput(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && createProject(domainInput)}
                  />
                </div>
                <div className="flex gap-2 w-full md:w-auto">
                  <button
                    onClick={() => createProject(domainInput)}
                    disabled={!domainInput || isProcessing}
                    className="flex-1 md:flex-none flex items-center justify-center gap-3 px-10 py-5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-2xl font-black transition-all shadow-xl shadow-indigo-200 active:scale-95 disabled:opacity-50"
                  >
                    {isProcessing ? <Loader2 className="h-6 w-6 animate-spin" /> : <Play className="h-6 w-6" />}
                    Scrape
                  </button>
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="flex items-center justify-center gap-3 px-8 py-5 bg-white border-2 border-slate-200 text-slate-700 rounded-2xl font-bold hover:border-indigo-500 hover:text-indigo-600 transition-all active:scale-95"
                    title="Upload XML/JSON"
                  >
                    <Upload className="h-6 w-6" />
                    Import
                  </button>
                  <input type="file" ref={fileInputRef} onChange={handleImport} className="hidden" accept=".xml,.txt,.json" />
                </div>
              </div>
            </div>

            <div className="space-y-6">
              <h3 className="text-xl font-black text-slate-900 flex items-center gap-3 px-2">
                <Layers className="h-6 w-6 text-indigo-500" />
                Recent Projects
              </h3>

              {projects.length === 0 ? (
                <div className="bg-white rounded-3xl border-2 border-dashed border-slate-200 py-24 text-center">
                  <p className="text-slate-400 font-bold text-lg">No active project records.</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                  {projects.map(project => (
                    <div 
                      key={project.id}
                      onClick={() => {
                        if (editingProjectId !== project.id) setActiveProjectId(project.id);
                      }}
                      className="group bg-white rounded-3xl border border-slate-200 p-8 cursor-pointer hover:border-indigo-500 hover:shadow-2xl transition-all relative overflow-hidden"
                    >
                      <div className="flex justify-between items-start mb-6">
                        <div className="flex items-center gap-4 flex-1 min-w-0">
                          <div className={`p-4 rounded-2xl shrink-0 ${project.status !== 'idle' ? 'bg-indigo-600 text-white animate-pulse' : 'bg-slate-100 text-slate-400'}`}>
                            <Globe className="h-7 w-7" />
                          </div>
                          <div className="flex-1 min-w-0 pr-2">
                            {editingProjectId === project.id ? (
                              <div className="flex items-center gap-2" onClick={(e) => e.stopPropagation()}>
                                <input 
                                  autoFocus
                                  className="w-full px-2 py-1 border border-indigo-300 rounded-lg text-sm font-bold focus:ring-2 focus:ring-indigo-500/20 focus:outline-none"
                                  value={editTitleValue}
                                  onChange={(e) => setEditTitleValue(e.target.value)}
                                  onKeyDown={(e) => {
                                    if (e.key === 'Enter') handleRename(project.id, editTitleValue);
                                    if (e.key === 'Escape') setEditingProjectId(null);
                                  }}
                                />
                                <button onClick={() => handleRename(project.id, editTitleValue)} className="text-emerald-500 hover:text-emerald-600">
                                  <Check className="h-4 w-4" />
                                </button>
                                <button onClick={() => setEditingProjectId(null)} className="text-slate-300 hover:text-slate-500">
                                  <X className="h-4 w-4" />
                                </button>
                              </div>
                            ) : (
                              <div className="flex flex-col min-w-0">
                                <div className="flex items-center gap-2 group/title min-w-0">
                                  <h4 className="font-black text-slate-900 break-all text-base md:text-lg group-hover:text-indigo-600 transition-colors leading-tight truncate-multiline">
                                    {project.domain}
                                  </h4>
                                  <button 
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      setEditingProjectId(project.id);
                                      setEditTitleValue(project.domain);
                                    }}
                                    className="opacity-0 group-hover:opacity-100 p-1 text-slate-400 hover:text-indigo-600 transition-opacity"
                                  >
                                    <Pencil className="h-4 w-4" />
                                  </button>
                                </div>
                                <p className="text-[10px] text-slate-400 font-black uppercase mt-1 tracking-wider">Activity: {new Date(project.lastScraped).toLocaleDateString()}</p>
                              </div>
                            )}
                          </div>
                        </div>
                        <button 
                          onClick={(e) => deleteProject(project.id, e)} 
                          className="p-2 text-slate-300 hover:text-rose-500 transition-all bg-slate-50 rounded-xl hover:bg-rose-50 shrink-0"
                        >
                          <Trash2 className="h-5 w-5" />
                        </button>
                      </div>

                      <div className="grid grid-cols-2 gap-4 mb-6 text-center">
                        <div className="bg-slate-50 rounded-2xl p-4">
                          <p className="text-[10px] font-black text-slate-400 uppercase mb-1">URLs</p>
                          <p className="text-xl font-black text-slate-900">{project.stats.totalUrls.toLocaleString()}</p>
                        </div>
                        <div className="bg-slate-50 rounded-2xl p-4">
                          <p className="text-[10px] font-black text-slate-400 uppercase mb-1">Status</p>
                          <p className={`text-[11px] font-black uppercase tracking-widest ${project.status !== 'idle' ? 'text-indigo-600' : 'text-emerald-600'}`}>{project.status}</p>
                        </div>
                      </div>

                      <div className="flex items-center justify-between pt-4 border-t border-slate-50 text-sm font-black text-indigo-600">
                        <span className="flex items-center gap-1">Detailed View <ChevronRight className="h-4 w-4" /></span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        ) : (
          <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
              <div className="relative" ref={settingsRef}>
                <button 
                  onClick={() => setShowSettings(!showSettings)}
                  className={`flex items-center gap-2 px-6 py-3 rounded-2xl border transition-all font-black text-xs uppercase tracking-widest shadow-sm ${showSettings ? 'bg-indigo-600 border-indigo-600 text-white' : 'bg-white border-slate-200 text-slate-600 hover:border-indigo-300'}`}
                >
                  <Settings className={`h-4 w-4 ${showSettings ? 'animate-spin-slow' : ''}`} />
                  Actions Menu
                </button>
                
                {showSettings && (
                  <div className="absolute top-full left-0 mt-2 w-72 bg-white rounded-2xl shadow-2xl border border-slate-200 py-2 z-50 animate-in fade-in zoom-in-95 duration-200">
                    <div className="px-4 py-2 text-[10px] font-black text-slate-400 uppercase tracking-widest border-b border-slate-50 mb-1">Intelligent Scraper</div>
                    <button 
                      onClick={startContentScrape}
                      className="w-full text-left px-4 py-4 text-sm font-bold text-slate-700 hover:bg-indigo-50 hover:text-indigo-600 flex items-center gap-3 transition-colors"
                    >
                      <ScanText className="h-5 w-5" /> Scrape All Content (Deep)
                    </button>
                    <div className="h-px bg-slate-50 my-1" />
                    <button 
                      onClick={() => {
                        if(confirm("Wipe all results for this project?")) {
                          setProjects(prev => prev.map(p => p.id === activeProjectId ? { ...p, results: [], stats: { ...p.stats, totalUrls: 0, totalImages: 0, scrapedPages: 0 } } : p));
                          setShowSettings(false);
                        }
                      }}
                      className="w-full text-left px-4 py-4 text-sm font-bold text-rose-600 hover:bg-rose-50 flex items-center gap-3 transition-colors"
                    >
                      <Trash2 className="h-5 w-5" /> Clear All Progress
                    </button>
                  </div>
                )}
              </div>
              
              <div className="flex items-center gap-3">
                <button onClick={() => exportProject(activeProject!)} className="flex items-center gap-2 px-6 py-3 bg-white border-2 border-slate-200 text-indigo-600 rounded-2xl font-bold hover:bg-indigo-50 transition-all shadow-sm">
                  <Download className="h-4 w-4" /> Export JSON
                </button>
                {activeProject?.status !== 'idle' ? (
                  <button onClick={() => setProjects(prev => prev.map(p => p.id === activeProjectId ? {...p, status: 'idle'} : p))} className="flex items-center gap-2 px-8 py-3 bg-slate-900 text-white rounded-2xl font-black shadow-lg transition-all">
                    <Square className="h-4 w-4 fill-current" /> Stop Process
                  </button>
                ) : (
                  <button onClick={() => {
                      setProjects(prev => prev.map(p => p.id === activeProjectId ? {
                        ...p, 
                        status: 'scraping', 
                        processed: [], 
                        stats: { ...p.stats, startTime: Date.now() }
                      } : p));
                    }} className="flex items-center gap-2 px-8 py-3 bg-indigo-600 text-white rounded-2xl font-black shadow-xl shadow-indigo-200 hover:bg-indigo-700 active:scale-95 transition-all">
                    <Play className="h-4 w-4 fill-current" /> Full Re-Sync
                  </button>
                )}
              </div>
            </div>

            <div className="bg-white rounded-3xl border border-slate-200 p-8 shadow-sm">
              <div className="flex items-center gap-6 mb-8">
                <div className="bg-indigo-50 p-6 rounded-3xl text-indigo-600 border border-indigo-100 shadow-inner">
                  <Globe className="h-10 w-10" />
                </div>
                <div className="min-w-0 flex-1">
                  <h2 className="text-2xl md:text-3xl font-black text-slate-900 tracking-tight break-all">{activeProject?.domain}</h2>
                  <p className="text-sm text-slate-400 font-bold flex items-center gap-2 mt-1 uppercase tracking-widest">
                    <CheckCircle2 className="h-4 w-4 text-emerald-500" /> Persistent DB Entry • {activeProject?.results.length} Found Links
                  </p>
                </div>
              </div>

              {activeProject?.status !== 'idle' && (
                <div className="bg-indigo-600 rounded-2xl p-8 mb-8 text-white shadow-2xl shadow-indigo-200 relative overflow-hidden">
                  <div className="flex items-center gap-6 mb-4 relative z-10">
                    <Loader2 className="h-8 w-8 animate-spin" />
                    <div className="flex-1">
                      <div className="flex justify-between items-end mb-2">
                        <p className="text-[11px] font-black uppercase opacity-70">
                          {activeProject.status === 'scraping' ? 'Parallel Analysis' : 'Deep Extraction'} ({progressPercent}%)
                        </p>
                        <p className="text-[10px] font-black uppercase opacity-70">{activeProject.processed.length} Items</p>
                      </div>
                      <div className="w-full bg-white/20 h-3 rounded-full overflow-hidden shadow-inner">
                        <div 
                          className="bg-white h-full transition-all duration-700" 
                          style={{ width: `${progressPercent}%` }}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="bg-white/10 px-4 py-3 rounded-xl border border-white/20 text-[10px] md:text-sm font-black truncate relative z-10">
                     Active Batch: {activeProject.queue.slice(0, BATCH_SIZE).join(', ')}
                  </div>
                </div>
              )}

              <StatsCards stats={activeProject?.stats!} />
            </div>

            <div className="bg-white rounded-3xl shadow-sm border border-slate-200 overflow-hidden flex flex-col min-h-[600px]">
              <div className="flex border-b border-slate-200 bg-slate-50/50 p-2">
                <button onClick={() => setActiveTab('urls')} className={`flex-1 py-4 text-xs font-black uppercase tracking-widest transition-all rounded-2xl ${activeTab === 'urls' ? 'bg-white shadow-sm text-indigo-600' : 'text-slate-500'}`}>
                  Analyzed Pages ({activeProject?.results.length})
                </button>
                <button onClick={() => setActiveTab('errors')} className={`flex-1 py-4 text-xs font-black uppercase tracking-widest transition-all rounded-2xl ${activeTab === 'errors' ? 'bg-white shadow-sm text-rose-600' : 'text-slate-500'}`}>
                  Crawl Failures ({activeProject?.errors.length})
                </button>
              </div>

              <div className="flex-1 flex flex-col">
                {activeTab === 'urls' ? <UrlList urls={activeProject?.results || []} /> : <ErrorLogs errors={activeProject?.errors || []} />}
              </div>
            </div>
          </div>
        )}
      </main>
      
      <style>{`
        @keyframes spin-slow { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
        .animate-spin-slow { animation: spin-slow 12s linear infinite; }
        .truncate-multiline {
          display: -webkit-box;
          -webkit-line-clamp: 2;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }
      `}</style>
    </div>
  );
};

export default App;
