
import React from 'react';
import { AlertTriangle, Clock, Terminal } from 'lucide-react';
import { ScrapingError } from '../types';

interface ErrorLogsProps {
  errors: ScrapingError[];
}

const ErrorLogs: React.FC<ErrorLogsProps> = ({ errors }) => {
  if (errors.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-slate-400">
        <Terminal className="h-12 w-12 mb-4 opacity-20" />
        <p className="text-lg font-medium">All systems normal</p>
        <p className="text-sm">Scraping errors will be logged here if they occur.</p>
      </div>
    );
  }

  return (
    <div className="p-4 space-y-3">
      {errors.map((error, idx) => (
        <div key={idx} className="bg-white border-l-4 border-rose-500 rounded-lg shadow-sm p-4 flex gap-4 animate-in slide-in-from-left duration-300">
          <div className="p-2 bg-rose-50 rounded-full h-fit">
            <AlertTriangle className="h-5 w-5 text-rose-600" />
          </div>
          <div className="flex-1 space-y-1">
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-bold text-slate-900 truncate max-w-lg" title={error.url}>
                {error.url}
              </h4>
              <span className="text-[10px] font-medium text-slate-400 flex items-center gap-1">
                <Clock className="h-3 w-3" /> {new Date(error.timestamp).toLocaleTimeString()}
              </span>
            </div>
            <p className="text-xs text-rose-600 font-medium">{error.message}</p>
          </div>
        </div>
      ))}
    </div>
  );
};

export default ErrorLogs;
