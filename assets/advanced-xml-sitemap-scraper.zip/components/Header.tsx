
import React from 'react';
import { Network, Github } from 'lucide-react';

interface HeaderProps {
  onLogoClick?: () => void;
}

const Header: React.FC<HeaderProps> = ({ onLogoClick }) => {
  return (
    <header className="bg-white border-b border-slate-200 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
        <div 
          className="flex items-center gap-3 cursor-pointer group select-none"
          onClick={onLogoClick}
        >
          <div className="bg-indigo-600 p-2 rounded-lg shadow-indigo-200 shadow-md group-hover:bg-indigo-700 transition-colors">
            <Network className="h-6 w-6 text-white" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-slate-900 tracking-tight leading-none group-hover:text-indigo-600 transition-colors">MapScraper Pro</h1>
            <span className="text-[10px] font-bold text-indigo-500 uppercase tracking-widest">Enterprise Edition</span>
          </div>
        </div>
        
        <div className="flex items-center gap-6">
          <nav className="hidden md:flex items-center gap-4">
            <a href="#" className="text-sm font-medium text-slate-500 hover:text-indigo-600 transition-colors">Documentation</a>
            <a href="#" className="text-sm font-medium text-slate-500 hover:text-indigo-600 transition-colors">API</a>
          </nav>
          <div className="h-6 w-px bg-slate-200" />
          <button className="text-slate-400 hover:text-slate-600 transition-colors">
            <Github className="h-5 w-5" />
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;
