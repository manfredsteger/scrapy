
import React from 'react';
import { FileText, Image as ImageIcon, Video, Clock, Activity, ListOrdered } from 'lucide-react';
import { ScrapingStats } from '../types';

interface StatsCardsProps {
  stats: ScrapingStats;
}

const StatsCards: React.FC<StatsCardsProps> = ({ stats }) => {
  const duration = stats.endTime ? (stats.endTime - stats.startTime) / 1000 : (Date.now() - stats.startTime) / 1000;
  
  const cards = [
    { label: 'Sitemaps', value: `${stats.processedSitemaps} / ${stats.totalSitemaps}`, icon: FileText, color: 'text-blue-500', bg: 'bg-blue-50' },
    { label: 'URLs Found', value: stats.totalUrls.toLocaleString(), icon: ListOrdered, color: 'text-indigo-500', bg: 'bg-indigo-50' },
    { label: 'Images', value: stats.totalImages.toLocaleString(), icon: ImageIcon, color: 'text-emerald-500', bg: 'bg-emerald-50' },
    { label: 'Videos', value: stats.totalVideos.toLocaleString(), icon: Video, color: 'text-amber-500', bg: 'bg-amber-50' },
    { label: 'Time Elapsed', value: `${duration.toFixed(1)}s`, icon: Clock, color: 'text-slate-500', bg: 'bg-slate-50' },
    { label: 'Rate', value: `${(stats.totalUrls / (duration || 1)).toFixed(1)}/s`, icon: Activity, color: 'text-rose-500', bg: 'bg-rose-50' },
  ];

  return (
    <div className="grid grid-cols-2 lg:grid-cols-6 gap-4">
      {cards.map((card, idx) => (
        <div key={idx} className="bg-white p-4 rounded-2xl shadow-sm border border-slate-200 transition-transform hover:scale-[1.02]">
          <div className="flex flex-col items-center text-center space-y-2">
            <div className={`${card.bg} ${card.color} p-2.5 rounded-xl`}>
              <card.icon className="h-5 w-5" />
            </div>
            <div className="space-y-0.5">
              <p className="text-xs font-medium text-slate-500 uppercase tracking-wider">{card.label}</p>
              <p className="text-lg font-bold text-slate-900 tracking-tight">{card.value}</p>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default StatsCards;
