
import React, { useState, useMemo } from 'react';
import { ExternalLink, Clock, ImageIcon, Video, Info, Search, FolderTree, FileText, X, CheckCircle, ScanText, FileCode } from 'lucide-react';
import { SitemapUrlEntry } from '../types';
// Fix: Added missing import for SitemapService
import { SitemapService } from '../services/sitemapService';

interface UrlListProps {
  urls: SitemapUrlEntry[];
}

const UrlList: React.FC<UrlListProps> = ({ urls }) => {
  const [filter, setFilter] = useState('');
  const [activeFolder, setActiveFolder] = useState<string | null>(null);
  const [previewEntry, setPreviewEntry] = useState<SitemapUrlEntry | null>(null);
  
  const folderStats = useMemo(() => {
    const stats: Record<string, number> = {};
    urls.forEach(url => {
      try {
        const path = new URL(url.loc).pathname;
        const segments = path.split('/').filter(s => s.length > 0);
        if (segments.length > 0) {
          const firstSegment = `/${segments[0]}/`;
          stats[firstSegment] = (stats[firstSegment] || 0) + 1;
        } else {
          stats['/ (Root)'] = (stats['/ (Root)'] || 0) + 1;
        }
      } catch (e) { /* ignore malformed */ }
    });
    return Object.entries(stats).sort((a, b) => b[1] - a[1]);
  }, [urls]);

  const filteredUrls = useMemo(() => {
    let result = urls;
    if (activeFolder) {
      if (activeFolder === '/ (Root)') {
        result = result.filter(u => new URL(u.loc).pathname === '/' || new URL(u.loc).pathname === '');
      } else {
        result = result.filter(u => new URL(u.loc).pathname.startsWith(activeFolder));
      }
    }
    if (filter) {
      const lower = filter.toLowerCase();
      result = result.filter(u => u.loc.toLowerCase().includes(lower));
    }
    return result;
  }, [urls, filter, activeFolder]);

  return (
    <div className="flex flex-col relative">
      {/* Sequential Reader Modal */}
      {previewEntry && (
        <div className="fixed inset-0 z-[100] bg-slate-900/60 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-5xl max-h-[92vh] overflow-hidden flex flex-col shadow-2xl animate-in zoom-in-95 duration-300">
            <div className="px-10 py-8 border-b border-slate-100 flex items-center justify-between bg-white">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-3 mb-1">
                  <span className="bg-indigo-50 text-indigo-600 text-[10px] font-black px-2 py-1 rounded uppercase tracking-widest">Deep Scrape</span>
                  <span className="text-[10px] font-bold text-slate-300 uppercase tracking-widest">{previewEntry.scrapedData?.timestamp}</span>
                </div>
                <h3 className="text-2xl font-black text-slate-900 truncate tracking-tight">{previewEntry.scrapedData?.title}</h3>
                <p className="text-xs font-bold text-slate-400 truncate mt-1">{previewEntry.loc}</p>
              </div>
              <button onClick={() => setPreviewEntry(null)} className="p-4 bg-slate-50 text-slate-400 rounded-2xl hover:bg-slate-100 transition-all hover:rotate-90">
                <X className="h-6 w-6" />
              </button>
            </div>
            
            <div className="flex-1 overflow-y-auto p-10 bg-slate-50/50">
              <div className="max-w-3xl mx-auto space-y-8 bg-white p-12 rounded-3xl shadow-sm border border-slate-100">
                <div className="border-b border-slate-50 pb-8 mb-8 flex justify-between items-center">
                  <div className="text-center flex-1 border-r border-slate-50">
                    <p className="text-[10px] font-black text-slate-400 uppercase mb-1">Total Words</p>
                    <p className="text-xl font-black text-indigo-600">{previewEntry.scrapedData?.wordCount.toLocaleString()}</p>
                  </div>
                  <div className="text-center flex-1 border-r border-slate-50">
                    <p className="text-[10px] font-black text-slate-400 uppercase mb-1">DOM Nodes</p>
                    <p className="text-xl font-black text-indigo-600">{previewEntry.scrapedData?.orderedElements.length}</p>
                  </div>
                  <div className="text-center flex-1">
                    <p className="text-[10px] font-black text-slate-400 uppercase mb-1">Media Assets</p>
                    <p className="text-xl font-black text-indigo-600">{previewEntry.scrapedData?.orderedElements.filter(e => e.type === 'media').length}</p>
                  </div>
                </div>

                {previewEntry.scrapedData?.orderedElements.map((el, i) => {
                  if (el.type === 'heading') {
                    // Fix: Use 'any' cast for dynamic tag names to avoid JSX namespace errors
                    const Tag = el.tag as any;
                    const size = el.tag === 'h1' ? 'text-4xl' : el.tag === 'h2' ? 'text-2xl' : 'text-xl';
                    return (
                      <div key={i} className="group relative">
                        <span className="absolute -left-16 top-1 text-[9px] font-black text-slate-300 uppercase opacity-0 group-hover:opacity-100 transition-opacity">{el.tag}</span>
                        <Tag className={`${size} font-black text-slate-900 leading-tight mt-12 mb-6`}>{el.content}</Tag>
                      </div>
                    );
                  }
                  if (el.type === 'paragraph') {
                    return (
                      <div key={i} className="group relative">
                        <span className="absolute -left-16 top-1 text-[9px] font-black text-slate-300 uppercase opacity-0 group-hover:opacity-100 transition-opacity">Para</span>
                        <p className="text-lg text-slate-600 leading-relaxed mb-6 whitespace-pre-wrap">{el.content}</p>
                      </div>
                    );
                  }
                  if (el.type === 'media') {
                    return (
                      <div key={i} className="my-10 bg-slate-50 rounded-2xl p-6 border border-dashed border-slate-200 group text-center">
                        <div className="flex items-center justify-center gap-4 mb-4">
                          {el.tag === 'img' ? <ImageIcon className="h-8 w-8 text-indigo-400" /> : <Video className="h-8 w-8 text-amber-400" />}
                          <div className="text-left">
                             <p className="text-[10px] font-black text-slate-400 uppercase">{el.tag === 'img' ? 'Source Image' : 'Media Asset'}</p>
                             <a href={el.src} target="_blank" className="text-xs font-bold text-indigo-600 truncate block max-w-sm hover:underline">{el.src}</a>
                          </div>
                        </div>
                        {el.alt && <p className="text-sm font-bold text-slate-400">Alt text: "{el.alt}"</p>}
                      </div>
                    );
                  }
                  return null;
                })}
                
                {(!previewEntry.scrapedData?.orderedElements || previewEntry.scrapedData.orderedElements.length === 0) && (
                  <div className="py-20 text-center">
                    <FileCode className="h-16 w-16 text-slate-200 mx-auto mb-4" />
                    <p className="text-slate-400 font-bold uppercase tracking-widest text-xs">No sequential data extracted.</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Hierarchy Header */}
      <div className="bg-slate-50/50 border-b border-slate-100 p-8">
        <div className="flex flex-wrap gap-3">
          <button onClick={() => { setActiveFolder(null); setFilter(''); }} className={`px-5 py-2.5 rounded-xl text-xs font-black transition-all border uppercase tracking-widest ${!activeFolder && !filter ? 'bg-indigo-600 border-indigo-600 text-white shadow-lg' : 'bg-white border-slate-200 text-slate-600 hover:border-indigo-400'}`}>
            Global Repository ({urls.length})
          </button>
          {folderStats.map(([folder, count]) => (
            <button key={folder} onClick={() => setActiveFolder(activeFolder === folder ? null : folder)} className={`px-5 py-2.5 rounded-xl text-xs font-black transition-all border flex items-center gap-3 uppercase tracking-widest ${activeFolder === folder ? 'bg-indigo-600 border-indigo-600 text-white shadow-lg' : 'bg-white border-slate-200 text-slate-600 hover:border-indigo-400'}`}>
              <span className={activeFolder === folder ? 'text-white' : 'text-indigo-500'}>{folder}</span>
              <span className={`px-2 py-0.5 rounded-lg text-[10px] ${activeFolder === folder ? 'bg-white/20' : 'bg-slate-100'}`}>{count}</span>
            </button>
          ))}
        </div>
      </div>

      <div className="p-6 border-b border-slate-100 bg-white sticky top-0 z-20 flex flex-col md:flex-row gap-4 items-center">
        <div className="relative flex-1 w-full">
          <Search className="absolute left-5 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-300" />
          <input 
            type="text" 
            placeholder="Search specific assets, extensions (.php) or segments..." 
            className="w-full pl-14 pr-6 py-5 bg-slate-50 border border-slate-200 rounded-2xl focus:outline-none focus:ring-4 focus:ring-indigo-500/5 focus:border-indigo-500 transition-all font-bold text-slate-700"
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
          />
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-50/50 text-slate-400 text-[10px] font-black uppercase tracking-widest border-b border-slate-100">
              <th className="px-10 py-6">Target Path & Origin</th>
              <th className="px-6 py-6">Sitemap Metadata</th>
              <th className="px-6 py-6">Deep Extraction</th>
              <th className="px-10 py-6 text-right">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {filteredUrls.slice(0, 500).map((url, idx) => {
              const urlObj = new URL(url.loc);
              const displayLoc = url.loc.replace(urlObj.origin, '');
              const isContent = url.loc.toLowerCase().endsWith('.php') || url.loc.toLowerCase().endsWith('.html');
              
              return (
                <tr key={idx} className="hover:bg-slate-50/40 transition-colors group">
                  <td className="px-10 py-6">
                    <div className="flex flex-col gap-1.5">
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] text-slate-400 font-black uppercase opacity-40">{urlObj.protocol.replace(':','')}</span>
                        <span className={`text-sm font-black transition-colors ${isContent ? 'text-indigo-600' : 'text-slate-900'}`}>{displayLoc || '/'}</span>
                      </div>
                      <div className="flex items-center gap-3">
                        {url.lastmod && <span className="text-[9px] font-black text-slate-400 flex items-center gap-1.5 bg-slate-50 px-2 py-0.5 rounded-lg"><Clock className="h-3 w-3" /> {new Date(url.lastmod).toLocaleDateString()}</span>}
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-6">
                    <div className="flex items-center gap-3">
                      <div className={`flex items-center gap-1.5 px-2 py-1 rounded-lg border ${url.images.length > 0 ? 'bg-indigo-50 border-indigo-100 text-indigo-600' : 'bg-slate-50 border-slate-100 text-slate-300'}`}>
                        <ImageIcon className="h-3 w-3" />
                        <span className="text-[10px] font-black">{url.images.length}</span>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-6">
                    {url.scrapedData ? (
                      <button onClick={() => setPreviewEntry(url)} className="flex items-center gap-2 px-4 py-2 bg-emerald-50 border border-emerald-100 text-emerald-600 rounded-xl font-black text-[9px] uppercase tracking-widest hover:bg-emerald-100 transition-all active:scale-95 shadow-sm">
                        <CheckCircle className="h-3.5 w-3.5" /> Sequential Data Ready
                      </button>
                    ) : (
                      <span className="text-[9px] font-black text-slate-300 uppercase tracking-widest italic">{SitemapService.isLikelyContentPage(url.loc) ? 'Pending Extraction' : 'Category/System Path'}</span>
                    )}
                  </td>
                  <td className="px-10 py-6 text-right">
                    <div className="flex items-center justify-end gap-3">
                       {url.scrapedData && (
                          <button onClick={() => setPreviewEntry(url)} className="p-2.5 text-slate-400 hover:text-indigo-600 transition-all bg-slate-50 rounded-2xl border border-transparent hover:border-indigo-100" title="Reader View">
                            <ScanText className="h-5 w-5" />
                          </button>
                       )}
                       <a href={url.loc} target="_blank" rel="noopener noreferrer" className="p-2.5 text-slate-400 hover:text-indigo-600 bg-slate-50 rounded-2xl border border-transparent hover:border-indigo-100 transition-all">
                        <ExternalLink className="h-5 w-5" />
                      </a>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default UrlList;
