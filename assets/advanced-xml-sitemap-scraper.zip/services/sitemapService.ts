
import { SitemapUrlEntry, ScrapedData, ScrapedElement } from '../types';

const CORS_PROXY = "https://api.allorigins.win/raw?url=";

export class SitemapService {
  /**
   * Heuristic to determine if a URL is an actual content page vs a category/folder
   */
  static isLikelyContentPage(url: string): boolean {
    try {
      const u = new URL(url);
      const path = u.pathname.toLowerCase();
      
      // If it ends with common content extensions, it's definitely a page
      if (path.endsWith('.php') || path.endsWith('.html') || path.endsWith('.htm') || path.endsWith('.aspx')) {
        return true;
      }

      // If it ends with a slash and has no segments, it's likely a home or category page
      const segments = path.split('/').filter(s => s.length > 0);
      
      // Heuristic: Content pages usually have more specific paths or a file extension
      // Exclude common "folder-only" looking paths that are shallow
      if (path.endsWith('/') && segments.length <= 1 && segments[0] !== 'index') {
        return false;
      }

      return true;
    } catch (e) {
      return false;
    }
  }

  static async fetchWithProxy(url: string): Promise<string> {
    const proxyUrl = `${CORS_PROXY}${encodeURIComponent(url)}`;
    const response = await fetch(proxyUrl);
    if (!response.ok) throw new Error(`Fetch failed: ${response.status}`);
    return await response.text();
  }

  /**
   * Sequential Scraper: Extracts headings and paragraphs in their DOM order
   */
  static async scrapePageContent(url: string): Promise<ScrapedData> {
    const html = await this.fetchWithProxy(url);
    const parser = new DOMParser();
    const doc = parser.parseFromString(html, "text/html");
    
    const orderedElements: ScrapedElement[] = [];
    let totalWords = 0;

    // We query for all semantic content blocks in one go to preserve document order
    const elements = doc.querySelectorAll('h1, h2, h3, h4, h5, h6, p, img, video');
    
    elements.forEach(el => {
      const tag = el.tagName.toLowerCase();
      
      if (tag.startsWith('h')) {
        const text = el.textContent?.trim() || '';
        if (text) {
          orderedElements.push({ type: 'heading', tag, content: text });
        }
      } else if (tag === 'p') {
        const text = el.textContent?.trim() || '';
        if (text && text.length > 5) {
          orderedElements.push({ type: 'paragraph', content: text });
          totalWords += text.split(/\s+/).length;
        }
      } else if (tag === 'img' || tag === 'video') {
        const src = el.getAttribute('src') || el.getAttribute('data-src');
        if (src) {
          try {
            const absolute = new URL(src, url).href;
            orderedElements.push({ 
              type: 'media', 
              tag, 
              src: absolute, 
              alt: el.getAttribute('alt') || undefined 
            });
          } catch (e) {}
        }
      }
    });

    return {
      title: doc.title || url,
      orderedElements,
      timestamp: new Date().toISOString(),
      wordCount: totalWords
    };
  }

  static validateUrl(url: string, baseDomain?: string): boolean {
    try {
      const u = new URL(url.trim());
      if (baseDomain) {
        const host = u.hostname.toLowerCase();
        const target = baseDomain.toLowerCase().replace(/^www\./, '').split('/')[0];
        return host.endsWith(target) || host.includes('.' + target);
      }
      return true;
    } catch (e) {
      return false;
    }
  }

  static async discoverSitemaps(domain: string): Promise<string[]> {
    const sitemaps = new Set<string>();
    let baseUrl = domain.trim();
    if (!baseUrl.startsWith('http')) baseUrl = `https://${baseUrl}`;
    baseUrl = baseUrl.replace(/\/$/, '');
    const cleanDomain = baseUrl.replace(/^https?:\/\//, '').split('/')[0];
    const paths = ['/robots.txt', '/sitemap.xml', '/sitemap_index.xml', '/sitemap-index.xml', '/sitemap1.xml'];
    
    for (const path of paths) {
      try {
        const content = await this.fetchWithProxy(baseUrl + path);
        if (path === '/robots.txt') {
          const matches = content.matchAll(/Sitemap:\s*(.*)/gi);
          for (const match of matches) {
            if (match[1]) {
              const url = match[1].trim();
              if (this.validateUrl(url, cleanDomain)) sitemaps.add(url);
            }
          }
        } else if (content.includes('<urlset') || content.includes('<sitemapindex')) {
          sitemaps.add(baseUrl + path);
        }
      } catch (e) {}
    }
    return Array.from(sitemaps);
  }

  static parseSitemap(xmlString: string, baseDomain?: string): { urls: SitemapUrlEntry[], subSitemaps: string[] } {
    const results: SitemapUrlEntry[] = [];
    const subSitemaps: string[] = [];
    const parser = new DOMParser();
    const xmlDoc = parser.parseFromString(xmlString, "text/xml");
    const isError = xmlDoc.getElementsByTagName("parsererror").length > 0;

    const getEls = (p: any, tag: string) => Array.from(p.getElementsByTagName(tag)) as Element[];

    if (!isError) {
      getEls(xmlDoc, "sitemap").forEach(idx => {
        const loc = idx.getElementsByTagName("loc")[0]?.textContent;
        if (loc && this.validateUrl(loc, baseDomain)) subSitemaps.push(loc.trim());
      });

      getEls(xmlDoc, "url").forEach(el => {
        const loc = el.getElementsByTagName("loc")[0]?.textContent;
        if (!loc || !this.validateUrl(loc, baseDomain)) return;
        const entry: SitemapUrlEntry = {
          loc: loc.trim(),
          lastmod: el.getElementsByTagName("lastmod")[0]?.textContent || undefined,
          images: [],
          videos: []
        };
        getEls(el, "image").forEach(img => {
          const iLoc = img.getElementsByTagName("loc")[0]?.textContent;
          if (iLoc) entry.images.push({ loc: iLoc });
        });
        results.push(entry);
      });
    }

    return { urls: results, subSitemaps };
  }
}
