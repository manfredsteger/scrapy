
export interface ImageMetadata {
  loc: string;
  title?: string;
  caption?: string;
  geoLocation?: string;
  license?: string;
}

export interface VideoMetadata {
  thumbnailLoc?: string;
  title?: string;
  description?: string;
  contentLoc?: string;
  playerLoc?: string;
  duration?: string;
  viewCount?: string;
  publicationDate?: string;
  rating?: string;
}

export interface NewsMetadata {
  name?: string;
  language?: string;
  publicationDate?: string;
  title?: string;
}

export interface ScrapedElement {
  type: 'heading' | 'paragraph' | 'media';
  tag?: string; // h1, h2, etc.
  content?: string;
  src?: string; // for media
  alt?: string;
}

export interface ScrapedData {
  title: string;
  orderedElements: ScrapedElement[];
  timestamp: string;
  wordCount: number;
}

export interface SitemapUrlEntry {
  loc: string;
  lastmod?: string;
  changefreq?: string;
  priority?: string;
  images: ImageMetadata[];
  videos: VideoMetadata[];
  news?: NewsMetadata;
  isMobile?: boolean;
  scrapedData?: ScrapedData;
}

export interface ScrapingError {
  url: string;
  message: string;
  timestamp: string;
}

export interface ScrapingStats {
  totalSitemaps: number;
  processedSitemaps: number;
  totalUrls: number;
  totalImages: number;
  totalVideos: number;
  startTime: number;
  endTime?: number;
  scrapedPages?: number;
}

export interface ScraperProject {
  id: string;
  domain: string;
  lastScraped: string;
  stats: ScrapingStats;
  results: SitemapUrlEntry[];
  errors: ScrapingError[];
  status: 'idle' | 'scraping' | 'content_scraping' | 'error';
  queue: string[];
  processed: string[]; 
}
